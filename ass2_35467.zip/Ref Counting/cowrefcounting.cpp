#include <iostream>
using namespace std;

#include "StringBuffer.h"

int main(){
	
	StringBuffer3 sto5("hamza", 5);
	StringBuffer3 sto6(sto5);
	sto5.append('x');

	return 0;
}