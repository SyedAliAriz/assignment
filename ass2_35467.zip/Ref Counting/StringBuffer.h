#include <iostream>
using namespace std;

class StringBuffer3{
public:

	StringBuffer3() {
		this->_strbuf = 0;
		this->_length = 0;
		this->_refcount = 0;
	}
	~StringBuffer3() {
		delete[] this->_strbuf;
		this->_refcount--;
	}

	StringBuffer3(const StringBuffer3& newString) {

		this->_strbuf = new char[newString.length()];
		this->_length = newString.length();
		this->_strbuf = newString._strbuf;
		this->_refcount++;
	}

	StringBuffer3(char* newString, int length) {
		_length = length;
		_strbuf = new char[length];

		for (int i = 0; i<this->_length; i++){
			this->_strbuf[i] = newString[i];
		}
	}

	char charAt(int index) const
	{
		if (index < _length) {
			return _strbuf[index];
		}
	}

	int length() const {
		return this->_length;
	}

	void append(char c) {
		this->_strbuf[this->_length] = c;
		this->_length++;
		this->_refcount--;
	}

	void reserve(int);

private:
	char* _strbuf;
	int _length;
	int _refcount;
};
