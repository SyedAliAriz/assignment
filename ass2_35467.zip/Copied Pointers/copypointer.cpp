#include <iostream>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include "StringBuffer.h"

StringBuffer::StringBuffer() 
{
	strBuffer = nullptr;	
	strlen = 0;		
}
StringBuffer::~StringBuffer()
{
	delete[] strBuffer;
}

StringBuffer::StringBuffer(const StringBuffer& object) {
	strlen = object.length(); 
	strBuffer = new char[strlen];  
	for (int i = 0; i < strlen; i++)
	{
		strBuffer[i] = object.charAt(i); 
	}
}
StringBuffer::StringBuffer(char* ptr, int len)
{
	strBuffer = new char[len];
	strlen = len;

	for (int i = 0; i < strlen - 1; i++)
	{
		strBuffer[i] = ptr[i];
	}
}
char StringBuffer::charAt(int i) const
{
	if (i < strlen)
	{
		return *(strBuffer + i);
	}
	else {

		throw"out of limit array index";
	}
}
int StringBuffer::length() const {
	return strlen;
}

void StringBuffer::reserve(int len)
{
	
	strBuffer = new char[len];
}
void StringBuffer::append(char c)
{
	char* temp = strBuffer;
	strlen++;
	strBuffer = new char[strlen];
	for (int i = 0; i < strlen - 1; i++)
	{
		strBuffer[i] = temp[i];
	}
	strBuffer[strlen - 1] = c;
	delete[] temp;
}


using namespace std;

int main(int argc, char** argv) {

	StringBuffer* object = new StringBuffer();
	object->append('h');
	object->append('e');
	object->append('l');
	object->append('l');
	object->append('o');
	cout << "Copied Pointers: " << endl;
	cout << "Object length: " << object->length() << endl;
	cout << "Object charAt 0: " << object->charAt(0) << endl;
	StringBuffer* object2(object);
	cout << "Object charAt 3: " << object2->charAt(3) << endl <<"press a key to delete the string";
	getchar();
	delete object;
	getchar();
	return 0;
}

